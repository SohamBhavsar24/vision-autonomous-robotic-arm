# LaTeX Bible — Engineering Capstone Dissertation Specification

> **Purpose:** This file is the single source of truth for the final-year engineering capstone dissertation ("Black Book") in `black_book/`. It documents the structure, mathematical formulations, figures, tables, code listings, and academic standards across all `.tex` files, ensuring Antigravity maintains complete continuity.
> **Rule:** This file MUST be updated whenever any `.tex` file in `black_book/` is modified.
> **Last Synchronized:** 2026-10-09 (Session 24 — Hardware & Testbed Ground Truth Audit)

---

## 1. Document Standards & Compilation Environment

- **Target Institution:** MIT World Peace University (MIT-WPU), Pune
- **Department:** Department of Electrical & Electronics Engineering (EEE), School of Engineering and Technology
- **Degree:** Bachelor of Technology (B.Tech) in Electrical & Electronics Engineering
- **Formatting Guidelines:**
  - **Paper Size:** ISO A4 (`210mm \times 297mm`)
  - **Left Margin (Gutter):** `38mm` (`1.5 in`) — strict requirement for hardbound black book binding
  - **Right, Top, Bottom Margins:** `25mm` (`1.0 in`)
  - **Line Spacing:** 1.5 line pitch (`\onehalfspacing` via `setspace`)
  - **Typography:** Times New Roman (`mathptmx` package)
  - **Page Numbering:** Two-tier schema:
    - Lowercase Roman (`i, ii, iii...`) for Front Matter (Title through Abstract)
    - Arabic numerals (`1, 2, 3...`) starting from Chapter 1 through Appendices
  - **Header & Footer:** Clean running headers with chapter title and folio (`fancyhdr`)
  - **Zero Margin Overflow Mandate:** Every wide table and TikZ figure must be wrapped in `\resizebox{\textwidth}{!}{...}` or `\resizebox{0.88\textwidth}{!}{...}` to eliminate `Overfull \hbox` warnings.
- **Compilation Engine:** **Tectonic** (`/opt/homebrew/bin/tectonic main.tex`)
- **Git Repository:** `https://github.com/SohamBhavsar24/black-book.git` (tracked on branch `main`)

---

## 2. Verified Physical Ground Truth Hardware & Rig Geometry

Based on complete project audits of `firmware/robot_driver/robot_driver.ino`, `architecture.md`, and `poster/index.html`:

| Subsystem | Ground Truth Specification | Description / Role |
|---|---|---|
| **Mounting Baseboard** | $50\text{ cm} \times 50\text{ cm}$ Wooden Plank | Rigid baseplate absorbing dynamic reaction torques during multi-axis manipulator motions |
| **Arm Placement** | Mounted on one side of plank | Anchored at the edge/pedestal to maximize reach into the forward manipulation field |
| **Active Workspace** | $25\text{ cm} \times 30\text{ cm}$ White Workspace | Calibrated tabletop manipulation area in front of the arm ($X \in [0, 30]\text{ cm}$, $Y \in [0, 25]\text{ cm}$) |
| **World Origin Fiducial** | ArUco Marker ID 2 on corner | Mounted at the corner of the workspace sheet, establishing the metric origin $(0, 0)\text{ cm}$ |
| **Manipulation Targets** | $4\text{ cm} \times 4\text{ cm} \times 4\text{ cm}$ Sponge Cubes | Lightweight blocks with ArUco markers on top (Tag 0: Block 1, Tag 1: Block 2) |
| **Vision System** | Logitech C270 HD USB Camera | Mounted on a rigid vertical pole/mast past the white workspace looking straight down (orthogonal top-down perspective, 30 FPS MJPEG) |
| **Base Actuator** | MG996R Servo (Channel 0) | Turntable azimuthal pivot ($\theta_1$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Shoulder Actuator** | MG996R Servo (Channel 1 / 2) | Upper arm elevation pitch ($\theta_2$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Elbow Actuator** | MG996R Servo (Channel 2 / 4) | Forearm articulation pitch ($\theta_3$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Wrist Pitch Actuator** | MG90S Micro Servo (Channel 3 / 6) | End-effector pitch orientation ($\theta_4$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Wrist Roll Actuator** | MG90S Micro Servo (Channel 4 / 8) | End-effector axial rotation ($\theta_5$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Gripper Jaw Actuator**| MG90S Micro Servo (Channel 5 / 10)| Parallel claw rack-and-pinion ($\theta_6$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Servo Driver** | NXP PCA9685 16-Channel 12-Bit | I2C PWM controller ($50\text{ Hz}$ update, 4096-step resolution, $400\text{ kHz}$ Fast I2C) |
| **Microcontroller** | Original Arduino Uno Rev3 | ATmega328P executing 115200 baud binary serial framing with 500ms safety watchdog |
| **Servo Power Supply** | 6V 5A External DC Power Supply | Dedicated high-current rail powering PCA9685 $V+$ and servos; common ground with Uno |
| **Logic Power Supply** | 5V USB / Regulated Rail | Powers Arduino Uno logic circuits and PCA9685 VCC independently |
| **Safety E-Stop** | Physical Cutoff Toggle Switch | Hardware switch instantly breaking the 6V servo power supply line |

---

## 3. Directory Structure & Master File Mapping

```
black_book/
├── main.tex                               # Master root LaTeX document & preambles
├── latex_bible.md                         # This file: single source of truth for LaTeX project
├── frontmatter/
│   └── frontmatter.tex                    # Title, Certificate, Declaration, Acknowledgement, Abstract
├── chapters/
│   ├── ch1_introduction.tex               # Background, Motivation, Problem Statement, Objectives, Scope
│   ├── ch2_literature_survey.tex          # Prior Art, Imitation Learning, ACT, IDW, ROS 2 Middleware
│   ├── ch3_hardware_and_kinematics.tex    # Mechanical CAD, 3D FK/IK, Actuation, ROS 2 URDF, Firmware Protocol
│   ├── ch4_perception_pipeline.tex        # 50x50 Rig, 25x30 Workspace, ArUco Detection, Homography, Radar
│   ├── ch5_imitation_learning_and_act.tex # Dataset Collection, 750-Episode Scale, ACT Transformer, Apple BLAS
│   ├── ch6_challenges_and_problem_solving.tex # 8 Major Engineering Hurdles Solved + Challenge Matrix
│   ├── ch7_experimental_results.tex       # Ablation Benchmarks, Loss Curves, Latency, Physical Sorting
│   └── ch8_conclusion_and_future_work.tex # Research Contributions, Industrial Applications, Future Scope
├── appendices.tex                         # Appendix A (BOM), B (Uno Pinout), C (ACT Code), D (Supabase Journal)
├── references.bib                         # 24 IEEE-formatted academic citations
└── figures/                               # Vector and schematic diagram resources
```

---

## 4. Comprehensive File-by-File Breakdown

### 4.1 `main.tex`
- **Role:** Master compilation root driving the entire document.
- **Preamble Packages:**
  - Geometry: `a4paper, left=38mm, right=25mm, top=25mm, bottom=25mm`
  - Typography: `mathptmx`, `microtype`, `setspace` (`\onehalfspacing`)
  - Mathematics: `amsmath`, `amssymb`, `amsfonts`, `bm`
  - Graphics & Diagrams: `graphicx`, `tikz`, `pgfplots`, `booktabs`, `multirow`, `adjustbox`
  - Hyperlinks: `hyperref` configured with navy/blue citation and URL colors
  - TikZ Libraries: `calc`, `shapes.geometric`, `arrows.meta`, `positioning`
- **Abbreviations Environment:**
  - Configured with `tabular*` spanning `\textwidth` with `@{\extracolsep{\fill}}lp{112mm}`.
  - Lists: ACT, AI, ArUco, BCE, BLAS, CAD, CPU, DDS, DLS, DOF, FK, FPS, GPU, HSV, I2C, IDW, IK, MJPEG, MLP, MSE, ONNX, PCA, PID, PLA, PWM, ROS 2, SVD, TCP, URDF, VLA.
- **Includes:** Calls `frontmatter/frontmatter.tex`, Chapters 1 through 8, `references.bib`, and `appendices.tex`.

### 4.2 `frontmatter/frontmatter.tex`
- **Role:** University statutory preliminary pages.
- **Sections & Elements:**
  1. **Title Page:** Project title, Department of EEE, School of Engineering & Technology, MIT-WPU, Pune. Lists all three candidates with official PRNs:
     - Soham Bhavsar — PRN: `1032232422`
     - Toshal Kumbhar — PRN: `1032232541`
     - Divyansh Dewangan — PRN: `1032233211`
  2. **Certificate of Approval:** Official guide endorsement, institutional seal, Head of Department signature block.
  3. **Candidates' Declaration:** Formal academic originality statement signed by all three authors with their respective PRNs.
  4. **Acknowledgements:** Mentions faculty guides, laboratory technicians, open-source robotics communities, and family support.
  5. **Abstract:** 300-word comprehensive executive technical abstract summarizing:
     - The hybrid perception-action architecture.
     - 6-DOF 3D-printed manipulator with 3x MG996R + 3x MG90S, Arduino Uno, PCA9685, 6V 5A power supply.
     - 50x50 cm wooden plank rig with 25x30 cm white workspace and overhead pole-mounted Logitech C270 camera.
     - Pure-NumPy ACT ($H=24$) with Apple Accelerate BLAS acceleration ($4.9\text{s/epoch}$).
     - Decoupled task decomposition (pick policy + deterministic Cosine S-Curve place).
     - Theta feature ablation raising physical pick success from $73.3\%$ to $90.0\%$ ($93.3\%$ overall).

### 4.3 `chapters/ch1_introduction.tex`
- **Role:** Contextual background, problem formulation, aim, objectives, and scope.
- **Sections:**
  - `1.1 Background and Motivation`: Discusses limitations of classical pre-programmed automation vs end-to-end visuomotor deep RL; introduces hybrid decoupled approach.
  - `1.2 Problem Statement`: Formulates the central research question regarding low-cost ($<\$200$) edge-executable imitation learning.
  - `1.3 Aim and Objectives`: Lists 8 specific measurable technical objectives:
    1. Electromechanical prototyping with 3x MG996R, 3x MG90S, Arduino Uno, PCA9685, 6V 5A external supply, and 50x50 cm wooden plank.
    2. Kinematic modeling & dynamic gripper calibration.
    3. Overhead metric perception with Logitech C270 and ArUco markers over 25x30 cm workspace.
    4. 3D WebGL digital twin with table penetration floor guard ($8.0\text{ mm}$).
    5. PS5 DualSense teleoperation demonstration collection infrastructure.
    6. Imitation policy engine (MLP vs pure-NumPy ACT $H=24$).
    7. System integration, theta ablation, and descent-apex grasp detection.
    8. Empirical physical evaluation and comparative benchmarking.
  - `1.4 Scope and Limitations`: Defines operational parameters (sponge blocks, 25x30 cm table, open-loop gripper, payload $\le 250\text{ g}$).
  - `1.5 Organization of the Report`: Structural summary of Chapters 1 to 8.

### 4.4 `chapters/ch2_literature_survey.tex`
- **Role:** Exhaustive academic survey of prior art and theoretical foundations.
- **Sections:**
  - `2.1 Classical Analytical Kinematics and Motion Planning`: Denavit-Hartenberg conventions, geometric inverse kinematics, Jacobian pseudo-inverse singularities.
  - `2.2 Visuomotor Imitation Learning and Behavioral Cloning`: Supervised policy learning, covariate shift (Ross et al., DAgger), compounding error accumulation.
  - `2.3 Action Chunking with Transformers (ACT)`: Temporal ensembling, transformer encoder-decoder architectures (Zhao et al., RSS 2023), multi-modal action distributions.
  - `2.4 Trajectory Blending and Non-Linear Phase Alignment`: Inverse Distance Weighting (IDW), dynamic time warping, trajectory phase synchronization.
  - `2.5 Comparative Analysis of Manipulation Paradigms`: Table 2.1 (`tab:lit_comparison`) benchmarking Classical IK, End-to-End Visuomotor RL, Standard BC (MLP), and the Proposed Decoupled ACT Framework.
  - `2.6 Robotics Middleware: ROS 2 Humble, Gazebo, and MoveIt 2`: Documents the transition from custom "BabyROS" prototyping to production ROS 2 Humble DDS, URDF modeling, Gazebo physics simulation, and MoveIt 2 trajectory validation.

### 4.5 `chapters/ch3_hardware_and_kinematics.tex`
- **Role:** Electromechanical hardware architecture, kinematics derivations, ROS 2 modeling, and firmware protocols.
- **Sections:**
  - `3.1 Mechanical System Overview`: CAD modeling in Fusion 360, 3D printing in PLA+ ($20\%$ infill).
    - **Figure 3.1 (`fig:kinematic_diagram`):** Scaled TikZ diagram of serial link geometry ($L_1 = 9.5\text{ cm}$, $L_2 = 12.0\text{ cm}$, $L_3 = 9.0\text{ cm}$, $L_4 = 14.0\text{ cm}$).
  - `3.2 3D Analytical Kinematics Formulation`:
    - Forward Kinematics (FK): Equations (\ref{eq:radial_proj})--(\ref{eq:fk_y}) computing end-effector tip $[X_e, Y_e, Z_e]^T$.
    - Analytical Inverse Kinematics (IK): Equations (\ref{eq:ik_theta1})--(\ref{eq:ik_theta4}) solving base azimuth $\theta_1$, wrist center decoupling $(r_w, Z_w)$, planar 2-link trigonometric solve for $\theta_3$ and $\theta_2$, and wrist pitch $\theta_4$.
  - `3.3 ROS 2 URDF Model, Singularity Analysis, and Jacobian Formulation`:
    - Forward transform chain and Ready Pose $\boldsymbol{\theta}_{\text{ready}} = [90^\circ, 65^\circ, 110^\circ, 90^\circ, 90^\circ]$ resolving to $\mathbf{P}_{\text{tool}}^{\text{world}} = [-0.081\text{ m}, 0.090\text{ m}, 0.930\text{ m}]^T$.
    - Geometric Jacobian $\mathbf{J}(\boldsymbol{\theta})$ and condition number $\kappa(\mathbf{J}) = \sigma_{\max}/\sigma_{\min}$. Ready Pose condition number $\kappa = 2.88$ (dexterous), compared to raw boot singular pose ($\kappa \to \infty$).
    - Damped Least-Squares (DLS) IK: Equation (\ref{eq:dls_ik}) with damping factor $\lambda = 0.05$.
  - `3.4 Actuation Subsystem and Power Budget`:
    - Actuators: 3x MG996R ($11.0\text{ kg}\cdot\text{cm}$) for Base ($\theta_1$), Shoulder ($\theta_2$), Elbow ($\theta_3$); 3x MG90S ($2.2\text{ kg}\cdot\text{cm}$) for Wrist Pitch ($\theta_4$), Wrist Roll ($\theta_5$), Gripper Jaw ($\theta_6$).
    - Driver: PCA9685 16-channel 12-bit PWM at $50\text{ Hz}$ update rate over $400\text{ kHz}$ Fast I2C.
    - Power Delivery: External regulated 6V 5A DC power supply (isolated servo rail) + 5V logic rail.
    - **Figure 3.2 (`fig:hardware_interconnect`):** Complete hardware interconnect TikZ diagram: Raspberry Pi 5 $\to$ USB Serial (115200 Baud) $\to$ Arduino Uno (ATmega328P, 500ms Watchdog) $\to$ Fast I2C (400 kHz) $\to$ PCA9685 $\to$ 6 Servos (3x MG996R + 3x MG90S) powered by External DC 6V / 5A.
  - `3.5 Dynamic Gripper Clamping Paradigm`: Rejection of hardcoded angles; dynamic user-calibrated `openAngle` ($10^\circ - 35^\circ$) and `closeAngle` ($85^\circ$) persisting in `kinematics_config.json`.
  - `3.6 Microcontroller Firmware and Anti-Jitter Framing Protocol`: Arduino Uno binary packet framing ($[0\text{xFF}, \theta_1, \theta_2, \theta_3, \theta_4, \theta_5, \theta_{\text{gripper}}]$), interrupt packet alignment parser, and 500ms safety watchdog auto-homing.

### 4.6 `chapters/ch4_perception_pipeline.tex`
- **Role:** Physical testbed setup, overhead computer vision, fiducial tracking, and spatial coordination.
- **Sections:**
  - `4.1 Overhead Monocular Vision Configuration & Physical Testbed Rig`:
    - Complete testbed geometry: $50\text{ cm} \times 50\text{ cm}$ wooden plank with robot mounted on one side.
    - $25\text{ cm} \times 30\text{ cm}$ white workspace sheet in front of the arm.
    - Logitech C270 camera mounted on an overhead vertical pole/mast looking straight down.
    - $640 \times 480$ MJPEG stream at 30 FPS via OpenCV 5.0.
  - `4.2 Fiducial Marker Detection and Sub-Pixel Corner Refinement`:
    - ArUco `DICT_4X4_50`: Marker 0 (Block 1), Marker 1 (Block 2), Marker 2 (World Origin).
    - Sub-pixel corner refinement equation (\ref{eq:subpix}) suppressing center jitter from $\pm 2.4\text{ mm}$ to $\pm 0.3\text{ mm}$.
  - `4.3 World Coordinate Transformation`:
    - **Figure 4.1 (`fig:workspace_blueprint`):** Scaled TikZ blueprint displaying the $50\text{ cm} \times 50\text{ cm}$ wooden plank, one-side robot base mount, $25\text{ cm} \times 30\text{ cm}$ white workspace, corner Marker 2 World Origin, $4\text{ cm} \times 4\text{ cm}$ blocks, and overhead Logitech C270 camera pole.
    - Metric homography equations (\ref{eq:world_x})--(\ref{eq:world_y}) and affine robot offset (\ref{eq:robot_transform}).
  - `4.4 Spatial 2D SVG Workspace Radar`: Real-time 2D SVG radar displaying 5cm grid ticks, marker pucks, orientation vectors, reachability geofence ($R \in [14, 31]\text{ cm}$), and 30Hz coordinate telemetry.
  - `4.5 Dual-Block Sequential Sorting Pipeline`: Sequential picking with Proximity-Based Downstream Sweep Order ($\arg\max X_i$) ensuring collision-free transit to left drop bins.

### 4.7 `chapters/ch5_imitation_learning_and_act.tex`
- **Role:** Teleoperation infrastructure, dataset scaling, ACT architecture, and edge BLAS acceleration.
- **Sections:**
  - `5.1 Teleoperation and Demonstration Collection`: PS5 DualSense controller, Direct Joint Velocity Rate Control with EMA low-pass filtering ($\alpha = 0.25$), 30Hz trajectory logging.
  - `5.2 Decoupled Pick-and-Place Architecture`: Decoupling visual pick policy ($60\text{--}90$ steps) from deterministic Cosine S-Curve place, reducing transitions by $38.6\%$ (from 17,824 to 10,934).
  - `5.3 Synthetic Demonstration Augmentation and Dataset Scaling`: Augmenting 30 human demonstrations with 720 kinematically validated synthetic trajectories ($N = 750$), empirical joint correlations, and ONNX Runtime export.
  - `5.4 Pure-NumPy Action Chunking with Transformers (ACT)`:
    - **Figure 5.1 (`fig:act_architecture`):** TikZ block diagram of ACT pipeline (Observation projection $\to$ Sinusoidal temporal queries $H=24$ $\to$ Multi-head self-attention $\to$ FFN $\to$ Dual heads for 5 joint angles and gripper probability).
    - Attention formulation, composite loss function with balanced gripper BCE weight.
  - `5.5 Apple Accelerate BLAS and Vectorized CPU Acceleration`: 2D tensor flattening dispatched to `cblas_sgemm` achieving a $32.6\times$ speedup ($4.9\text{s/epoch}$ CPU training, $<2\text{ ms}$ inference).
  - `5.6 Receding Horizon Temporal Ensembling`: Online smoothing with exponential weights $w_k = \exp(-0.05 \cdot k)$.

### 4.8 `chapters/ch6_challenges_and_problem_solving.tex`
- **Role:** Dedicated chapter documenting 8 major engineering challenges faced and solved.
- **Sections:**
  - `6.1 Introduction to Experimental Anomalies`
  - `6.2 Hardware Actuation, Timing, and Bus Protocols`:
    - Challenge 1: Teleoperation frame flooding vs Arduino Uno serial buffer overrun $\to$ 30Hz clamp, $400\text{ kHz}$ Fast I2C, $0\text{xFF}$ framing.
    - Challenge 2: Servo spline drift & hardcoded gripper fallacy $\to$ Dynamic Gripper State Paradigm with UI calibration.
  - `6.3 Perception Noise and Object Symmetry Dilemmas`:
    - Challenge 3: Sponge cube $\theta$ ambiguity $\to$ Feature Dimensionality Ablation ($[θ_1..θ_5, \text{grip}, X, Y]$, 8 dims), boosting pick success from $73.3\%$ to $90.0\%$. Table 6.1 (`tab:ablation_comparison`).
  - `6.4 Imitation Learning Distribution Shift and Multi-Modality`:
    - Challenge 4: Multimodal trajectory averaging in drop phase $\to$ Decoupled task decomposition.
    - Challenge 5: Step-wise IDW temporal dip flattening $\to$ Phase-Aligned Tri-Anchor IDW blending.
    - Challenge 6: Demonstration class imbalance (85:15 open:closed) $\to$ Kinematic Descent-Apex Grasp Detection ($\theta_3 \ge 154^\circ$ after $\ge 35$ approach frames).
  - `6.5 Safety Geofencing and Edge Compute Constraints`:
    - Challenge 7: Tabletop collision & gear stripping $\to$ 3D WebGL Digital Twin mesh-forward-transform table geofencing ($Y_{\text{floor\_limit}} = 8.0\text{ mm}$).
    - Challenge 8: Raspberry Pi 5 CPU multi-head attention latency $\to$ Pure-NumPy contiguous 2D BLAS flattening.
  - `6.6 Summary Matrix of Engineering Challenges`: Table 6.2 (`tab:challenges_matrix`) summarizing all 8 challenges, root causes, solutions, and measured metrics.

### 4.9 `chapters/ch7_experimental_results.tex`
- **Role:** Quantitative empirical benchmarks, training convergence, latency, and physical trials.
- **Sections:**
  - `7.1 Model Training Convergence and Offline Validation`:
    - **Figure 7.1 (`fig:training_loss`):** TikZ/PGFPlots convergence curves comparing ACT ($H=24$) vs Deep MLP ($H=1$) over 30 epochs.
    - **Table 7.1 (`tab:model_loss`):** Quantitative metrics comparing `act_with_theta` (loss: 16.5912), `act_no_theta` (loss: 17.8150), `v1` (loss: 0.3627), `excluding_block_theta` (loss: 0.3668), `v2` (loss: 0.4778), and `v3` (loss: 0.5109).
  - `7.2 Computational Latency and Inference Benchmarks`: Benchmarks across MacBook and Raspberry Pi 5 (Perception: $11.8\text{ ms}$, ACT Inference: $1.9\text{ ms}$, Serial: $0.5\text{ ms}$, Total: $14.2\text{ ms} < 33.3\text{ ms}$ budget).
  - `7.3 Physical Pick-and-Place Experimental Benchmarks`:
    - **Table 7.2 (`tab:physical_results`):** Systematic physical trials across 30 randomized trials evaluating Approach Accuracy, Grasp Success, Place Accuracy, Cycle Time, and Overall Success ($93.3\%$ for ACT no theta).
  - `7.4 Dual-Block Sequential Sorting Verification`: Physical validation of Tag 0 and Tag 1 sequential clearance.

### 4.10 `chapters/ch8_conclusion_and_future_work.tex`
- **Role:** Synthesis of contributions, real-world utility, and future extensions.
- **Sections:**
  - `8.1 Summary of Research Contributions`: 6 core technical contributions delivered.
  - `8.2 Industrial, Commercial, and Educational Applications`: Micro-warehousing, laboratory sample handling, pedagogical robotics.
  - `8.3 Future Research Pathways`: Multi-object HSV color segmentation, dataset scaling (60 and 90 demos), diffusion policies and VLA models, closed-loop image Jacobian visual servoing.

### 4.11 `appendices.tex`
- **Role:** Supplementary hardware specifications, pinout tables, algorithms, and engineering logs.
- **Appendices:**
  - **Appendix A: Bill of Materials and Hardware Specifications**:
    - **Table A.1 (`tab:bom`):** Complete BOM with specifications, quantities, unit costs (INR), and totals:
      - 3x MG996R Servos (Base, Shoulder, Elbow)
      - 3x MG90S Micro Servos (Wrist Pitch, Wrist Roll, Gripper)
      - PCA9685 16-Channel 12-Bit I2C Driver
      - Arduino Uno Rev3 (original ATmega328P board)
      - Raspberry Pi 5 (4GB RAM)
      - 6V 5A External DC Power Supply (isolated servo rail)
      - Logitech C270 HD Overhead Camera
      - PLA+ Tough 3D Printing Filament ($0.8\text{ kg}$)
      - M3/M4 Hex Hardware & Bearings
      - $50\text{ cm} \times 50\text{ cm}$ Wooden Plank Baseboard
      - $25\text{ cm} \times 30\text{ cm}$ Calibrated White Workspace Sheet
      - $4\text{ cm} \times 4\text{ cm}$ Sponge Cubes & ArUco Markers
      - Total cost: $\approx \text{INR } 13,850$ ($\approx \$165.50$ USD).
  - **Appendix B: Microcontroller Pinout and Wiring Interconnect**:
    - **Table B.1 (`tab:pinout`):** Arduino Uno Rev3 to PCA9685 signal wiring (A4 SDA, A5 SCL, 5V VCC, GND), External 6V 5A power wiring (V+ and Power GND), and servo channel allocations (Channels 0, 2, 4, 6, 8, 10).
  - **Appendix C: Core Pure-NumPy ACT Attention Engine**:
    - **Listing C.1:** Python code snippet for the 2D matrix flattening BLAS optimization.
  - **Appendix D: Project Engineering Journal and Academic Logbook**:
    - **Table D.1 (`tab:journal_log`):** Chronological log of all 29 engineering sessions synthesized from the live Supabase PostgreSQL database (`pzewxynfhrylnqbkkeeq.supabase.co`) from 06 July 2026 to 01 October 2026.

### 4.12 `references.bib`
- **Role:** Complete academic citations formatted for IEEE style.
- **Total Citations:** 24 citations covering:
  - Imitation learning: Pomerleau (1989), Ross et al. (2011, DAgger), Argall et al. (2009).
  - Action Chunking: Zhao et al. (RSS 2023, ACT), Chi et al. (RSS 2023, Diffusion Policy).
  - Transformers: Vaswani et al. (2017).
  - Kinematics & Robotics: Craig (2005), Spong et al. (2006), Siciliano et al. (2008), Buss (2004, DLS IK).
  - Middleware: Macenski et al. (Science Robotics 2022, ROS 2), Chitta et al. (2012, MoveIt), Koenig & Howard (2004, Gazebo).
  - Computer Vision & Fiducials: Bradski (2000, OpenCV), Garrido-Jurado et al. (2014, ArUco), Romero-Ramirez et al. (2018).
  - Edge Computing & Digital Twins: Raspberry Pi Foundation, Three.js team.

---

## 5. Synchronization Protocol with `agent_bible.md`

Whenever changes occur in the physical robot or software stack:
1. **Hardware Verification:** Check that actuator counts, motor models, microcontroller types, and power supply voltages match Section 2 of this file.
2. **Model Metrics Synchronization:** When new models are trained (`models_registry.json`), update Table 7.1 in `ch7_experimental_results.tex` and Section 4.9 of this file.
3. **Database Journal Sync:** When new entries are posted to the Supabase `journal_entries` table, append them to Table D.1 in `appendices.tex`.
4. **Compile & Zero Margin Bounds Verification:** Always recompile using `/opt/homebrew/bin/tectonic main.tex` and check that all tables and figures remain strictly within text margins.
5. **Double-Commit Protocol:** Commit updates to both the primary workspace git repository and the dedicated `black-book` repository.
