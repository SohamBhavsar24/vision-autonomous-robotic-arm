#!/usr/bin/env python3
"""
Black Book Web Studio — Local Overleaf-Style Backend Server
Serves the web editor, persists edits directly to disk in black_book/,
handles image uploads to figures/, runs Tectonic compilations with SyncTeX,
and serves the live compiled main.pdf.
"""

import os
import sys
import re
import json
import time
import base64
import subprocess
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn

STUDIO_DIR = os.path.dirname(os.path.abspath(__file__))
BLACK_BOOK_DIR = os.path.dirname(STUDIO_DIR)
FIGURES_DIR = os.path.join(BLACK_BOOK_DIR, "figures")
MAIN_TEX = os.path.join(BLACK_BOOK_DIR, "main.tex")
MAIN_PDF = os.path.join(BLACK_BOOK_DIR, "main.pdf")
TECTONIC_BIN = "/opt/homebrew/bin/tectonic"
DEFAULT_PORT = 8060

os.makedirs(FIGURES_DIR, exist_ok=True)


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class StudioHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STUDIO_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def read_post_json(self):
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            return {}
        post_data = self.rfile.read(content_length)
        try:
            return json.loads(post_data.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        # 1. API: Server & PDF Status (for 10s auto-polling without screen jump)
        if path == "/api/status":
            pdf_mtime = os.path.getmtime(MAIN_PDF) if os.path.exists(MAIN_PDF) else 0
            pdf_size = os.path.getsize(MAIN_PDF) if os.path.exists(MAIN_PDF) else 0
            self.send_json({
                "success": True,
                "pdf_exists": os.path.exists(MAIN_PDF),
                "pdf_mtime": pdf_mtime,
                "pdf_size": pdf_size,
                "server_time": time.time()
            })
            return

        # 2. API: File Tree
        if path == "/api/tree":
            try:
                tree = self.get_file_tree()
                self.send_json({"success": True, "tree": tree})
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 3. API: Read File
        if path == "/api/file":
            rel_path = query.get("path", [""])[0]
            if not rel_path:
                self.send_json({"success": False, "error": "Missing path parameter"}, 400)
                return
            full_path = os.path.normpath(os.path.join(BLACK_BOOK_DIR, rel_path))
            if not full_path.startswith(BLACK_BOOK_DIR):
                self.send_json({"success": False, "error": "Access denied"}, 403)
                return
            if not os.path.exists(full_path):
                self.send_json({"success": False, "error": "File not found"}, 404)
                return
            try:
                with open(full_path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.send_json({
                    "success": True,
                    "path": rel_path,
                    "content": content,
                    "mtime": os.path.getmtime(full_path),
                    "size": os.path.getsize(full_path)
                })
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 4. API: Figures Gallery
        if path == "/api/figures":
            try:
                figs = []
                for fname in sorted(os.listdir(FIGURES_DIR)):
                    if fname.startswith("."):
                        continue
                    fpath = os.path.join(FIGURES_DIR, fname)
                    if os.path.isfile(fpath):
                        ext = os.path.splitext(fname)[1].lower()
                        figs.append({
                            "name": fname,
                            "path": f"figures/{fname}",
                            "size": os.path.getsize(fpath),
                            "mtime": os.path.getmtime(fpath),
                            "is_image": ext in [".png", ".jpg", ".jpeg", ".pdf", ".svg"]
                        })
                self.send_json({"success": True, "figures": figs})
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 5. API: Stream PDF (raw binary for PDF.js or iframe)
        if path == "/api/pdf":
            if not os.path.exists(MAIN_PDF):
                self.send_json({"success": False, "error": "main.pdf not found. Please compile first."}, 404)
                return
            try:
                with open(MAIN_PDF, "rb") as f:
                    pdf_bytes = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Length", str(len(pdf_bytes)))
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                self.send_header("Content-Disposition", "inline; filename=main.pdf")
                self.end_headers()
                self.wfile.write(pdf_bytes)
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 6. Serve Figures (e.g. /figures/robot_cad.png)
        if path.startswith("/figures/"):
            fname = path[len("/figures/"):]
            fpath = os.path.normpath(os.path.join(FIGURES_DIR, fname))
            if fpath.startswith(FIGURES_DIR) and os.path.exists(fpath):
                ctype, _ = mimetypes.guess_type(fpath)
                if not ctype:
                    ctype = "application/octet-stream"
                with open(fpath, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return

        # Default static file serving from studio/ (includes /vendor/pdf.min.js)
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # 1. API: Save File
        if path == "/api/save":
            try:
                data = self.read_post_json()
                rel_path = data.get("path", "")
                content = data.get("content", "")
                if not rel_path:
                    self.send_json({"success": False, "error": "Missing path"}, 400)
                    return
                full_path = os.path.normpath(os.path.join(BLACK_BOOK_DIR, rel_path))
                if not full_path.startswith(BLACK_BOOK_DIR):
                    self.send_json({"success": False, "error": "Access denied"}, 403)
                    return
                
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content)
                
                self.send_json({
                    "success": True,
                    "path": rel_path,
                    "mtime": os.path.getmtime(full_path),
                    "size": os.path.getsize(full_path)
                })
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 2. API: Search Code from PDF Selection (PDF -> Code Jump)
        if path == "/api/search_code":
            try:
                data = self.read_post_json()
                query = data.get("query", "").strip()
                active_path = data.get("active_path", "")
                if not query:
                    self.send_json({"success": False, "found": False})
                    return

                res = self.find_code_match(query, active_path)
                self.send_json(res)
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 3. API: Upload Image
        if path == "/api/upload_image":
            try:
                data = self.read_post_json()
                filename = data.get("filename", "")
                b64_data = data.get("data", "")
                if not filename or not b64_data:
                    self.send_json({"success": False, "error": "Missing filename or data"}, 400)
                    return
                
                clean_name = os.path.basename(filename).replace(" ", "_")
                if "," in b64_data:
                    b64_data = b64_data.split(",", 1)[1]
                
                raw_bytes = base64.b64decode(b64_data)
                target_path = os.path.join(FIGURES_DIR, clean_name)
                with open(target_path, "wb") as f:
                    f.write(raw_bytes)
                
                label_name = os.path.splitext(clean_name)[0].lower()
                latex_snippet = (
                    "\\begin{figure}[!htbp]\n"
                    "\\centering\n"
                    f"\\includegraphics[width=0.85\\textwidth]{{figures/{clean_name}}}\n"
                    f"\\caption{{Description of {clean_name}.}}\n"
                    f"\\label{{fig:{label_name}}}\n"
                    "\\end{figure}"
                )
                
                self.send_json({
                    "success": True,
                    "filename": clean_name,
                    "rel_path": f"figures/{clean_name}",
                    "latex_snippet": latex_snippet,
                    "size": len(raw_bytes)
                })
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 4. API: Compile with Tectonic & SyncTeX
        if path == "/api/compile":
            t0 = time.time()
            try:
                tectonic_cmd = [TECTONIC_BIN, "--synctex", "main.tex"]
                res = subprocess.run(
                    tectonic_cmd,
                    cwd=BLACK_BOOK_DIR,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=90
                )
                dt_ms = int((time.time() - t0) * 1000)
                success = (res.returncode == 0)
                
                page_count = 0
                if success and os.path.exists(MAIN_PDF):
                    try:
                        self.rebuild_synctex_map()
                    except Exception:
                        pass
                    try:
                        import zlib
                        with open(MAIN_PDF, "rb") as f:
                            pdf_data = f.read()
                        obj_stms = re.findall(rb'<<.*?/Type\s*/ObjStm.*?>>\s*stream\r?\n(.*?)\r?\nendstream', pdf_data, re.DOTALL)
                        all_obj = "\n".join(zlib.decompress(s).decode("latin1", errors="ignore") for s in obj_stms)
                        page_count = len(re.findall(r'/Type\s*/Page\b', all_obj))
                    except Exception:
                        page_count = 0

                self.send_json({
                    "success": success,
                    "returncode": res.returncode,
                    "output": res.stdout,
                    "time_ms": dt_ms,
                    "page_count": page_count,
                    "pdf_size": os.path.getsize(MAIN_PDF) if os.path.exists(MAIN_PDF) else 0,
                    "pdf_mtime": os.path.getmtime(MAIN_PDF) if os.path.exists(MAIN_PDF) else 0,
                    "timestamp": time.time()
                })
            except subprocess.TimeoutExpired:
                self.send_json({"success": False, "error": "Compilation timed out after 90 seconds"}, 504)
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 5. API: Repack Zip
        if path == "/api/repack_zip":
            try:
                zip_cmd = [
                    "zip", "-r", "Black_Book_LaTeX_Project.zip",
                    "main.tex", "references.bib", "appendices.tex", "latex_bible.md",
                    "frontmatter", "chapters", "figures"
                ]
                res = subprocess.run(zip_cmd, cwd=BLACK_BOOK_DIR, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                zip_path = os.path.join(BLACK_BOOK_DIR, "Black_Book_LaTeX_Project.zip")
                self.send_json({
                    "success": res.returncode == 0,
                    "size": os.path.getsize(zip_path) if os.path.exists(zip_path) else 0,
                    "output": res.stdout
                })
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        # 6. API: Git Sync
        if path == "/api/git_sync":
            try:
                subprocess.run(["git", "add", "-A"], cwd=BLACK_BOOK_DIR, capture_output=True, text=True)
                commit_msg = f"update(studio): synchronized edits via Black Book Web Studio [{time.strftime('%Y-%m-%d %H:%M:%S')}]"
                commit_res = subprocess.run(["git", "commit", "-m", commit_msg], cwd=BLACK_BOOK_DIR, capture_output=True, text=True)
                push_res = subprocess.run(["git", "push", "origin", "main"], cwd=BLACK_BOOK_DIR, capture_output=True, text=True)
                self.send_json({
                    "success": push_res.returncode == 0,
                    "commit_output": commit_res.stdout + commit_res.stderr,
                    "push_output": push_res.stdout + push_res.stderr
                })
            except Exception as e:
                self.send_json({"success": False, "error": str(e)}, 500)
            return

        self.send_json({"success": False, "error": "Endpoint not found"}, 404)

    def find_code_match(self, query, active_path=None):
        """Searches across .tex files for query text extracted from PDF selection."""
        # Clean query: strip non-alphanumeric except spaces
        clean_words = re.findall(r'[A-Za-z0-9_]{3,}', query)
        if not clean_words:
            return {"success": True, "found": False}

        search_tokens = clean_words[:6]  # Use up to 6 significant words
        phrase = " ".join(search_tokens).lower()

        # Gather candidate files (prioritize active file if provided)
        candidate_files = []
        if active_path and os.path.exists(os.path.join(BLACK_BOOK_DIR, active_path)):
            candidate_files.append(active_path)

        for root, dirs, files in os.walk(BLACK_BOOK_DIR):
            if "studio" in root or ".git" in root or "vendor" in root:
                continue
            for f in files:
                if f.endswith(".tex") or f.endswith(".bib"):
                    rel = os.path.relpath(os.path.join(root, f), BLACK_BOOK_DIR)
                    if rel not in candidate_files:
                        candidate_files.append(rel)

        for rel in candidate_files:
            full = os.path.join(BLACK_BOOK_DIR, rel)
            try:
                with open(full, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                lines = content.splitlines()

                # 0. Multi-line whitespace-flexible match across line wraps
                if len(search_tokens) >= 2:
                    regex_pat = r'\s+'.join(re.escape(tok) for tok in search_tokens[:5])
                    m = re.search(regex_pat, content, re.IGNORECASE)
                    if m:
                        start_pos = m.start()
                        end_pos = m.end()
                        line_no = content[:start_pos].count('\n') + 1
                        line_str = content[start_pos:end_pos].strip()
                        return {
                            "success": True,
                            "found": True,
                            "path": rel,
                            "line": line_no,
                            "char_start": start_pos,
                            "char_end": end_pos,
                            "line_text": line_str
                        }

                # 1. Exact phrase match in lines
                for l_idx, line in enumerate(lines):
                    # Strip common LaTeX markup
                    clean_line = re.sub(r'\\[a-zA-Z]+(\{[^}]*\})?', ' ', line).lower()
                    if phrase in clean_line:
                        # Find char position
                        char_start = sum(len(lines[i]) + 1 for i in range(l_idx))
                        return {
                            "success": True,
                            "found": True,
                            "path": rel,
                            "line": l_idx + 1,
                            "char_start": char_start,
                            "char_end": char_start + len(line),
                            "line_text": line.strip()
                        }

                # 2. Key token intersection match
                best_score = 0
                best_line_idx = -1
                for l_idx, line in enumerate(lines):
                    line_lower = line.lower()
                    score = sum(1 for tok in search_tokens if tok.lower() in line_lower)
                    if score > best_score:
                        best_score = score
                        best_line_idx = l_idx

                if best_score >= max(2, len(search_tokens) // 2):
                    line = lines[best_line_idx]
                    char_start = sum(len(lines[i]) + 1 for i in range(best_line_idx))
                    return {
                        "success": True,
                        "found": True,
                        "path": rel,
                        "line": best_line_idx + 1,
                        "char_start": char_start,
                        "char_end": char_start + len(line),
                        "line_text": line.strip()
                    }
            except Exception:
                continue

        return {"success": True, "found": False}

    def get_file_tree(self):
        """Constructs an organized hierarchical file tree of the Black Book."""
        categories = {
            "Core": [],
            "Front Matter": [],
            "Chapters": [],
            "Back Matter": [],
            "Figures": [],
            "Documentation": []
        }

        if os.path.exists(MAIN_TEX):
            categories["Core"].append({"name": "main.tex", "path": "main.tex", "type": "tex", "size": os.path.getsize(MAIN_TEX)})

        fm_dir = os.path.join(BLACK_BOOK_DIR, "frontmatter")
        if os.path.exists(fm_dir):
            for f in sorted(os.listdir(fm_dir)):
                if f.endswith(".tex"):
                    fp = os.path.join(fm_dir, f)
                    categories["Front Matter"].append({"name": f, "path": f"frontmatter/{f}", "type": "tex", "size": os.path.getsize(fp)})

        ch_dir = os.path.join(BLACK_BOOK_DIR, "chapters")
        if os.path.exists(ch_dir):
            for f in sorted(os.listdir(ch_dir)):
                if f.endswith(".tex"):
                    fp = os.path.join(ch_dir, f)
                    categories["Chapters"].append({"name": f, "path": f"chapters/{f}", "type": "tex", "size": os.path.getsize(fp)})

        for f in ["appendices.tex", "references.bib"]:
            fp = os.path.join(BLACK_BOOK_DIR, f)
            if os.path.exists(fp):
                categories["Back Matter"].append({"name": f, "path": f, "type": "bib" if f.endswith(".bib") else "tex", "size": os.path.getsize(fp)})

        if os.path.exists(FIGURES_DIR):
            for f in sorted(os.listdir(FIGURES_DIR)):
                if not f.startswith("."):
                    fp = os.path.join(FIGURES_DIR, f)
                    categories["Figures"].append({"name": f, "path": f"figures/{f}", "type": "image", "size": os.path.getsize(fp)})

        for f in ["latex_bible.md", "README.md"]:
            fp = os.path.join(BLACK_BOOK_DIR, f)
            if os.path.exists(fp):
                categories["Documentation"].append({"name": f, "path": f, "type": "md", "size": os.path.getsize(fp)})

        return categories

    def rebuild_synctex_map(self):
        """Parses main.synctex.gz into studio/synctex_map.json for deterministic coordinate sync."""
        import gzip
        synctex_gz = os.path.join(BLACK_BOOK_DIR, "main.synctex.gz")
        if not os.path.exists(synctex_gz):
            return
        with gzip.open(synctex_gz, "rt", encoding="utf-8", errors="ignore") as f:
            raw = f.read()

        inputs = {}
        for m in re.finditer(r'^Input:(\d+):(.+)$', raw, re.MULTILINE):
            tag, path_str = int(m.group(1)), m.group(2).strip()
            if path_str:
                rel = os.path.relpath(os.path.normpath(path_str), BLACK_BOOK_DIR).replace("\\", "/")
                if not rel.startswith("..") and (rel.endswith(".tex") or rel.endswith(".bib") or rel.endswith(".bbl")):
                    inputs[tag] = rel

        forward = {}
        pages = {}
        page_splits = re.split(r'^\{(\d+)\r?$', raw, flags=re.MULTILINE)
        rec_re = re.compile(r'^([(\[hvgkx])(\d+),(\d+):(-?\d+),(-?\d+)(?::(-?\d+),(-?\d+),(-?\d+))?', re.MULTILINE)

        for i in range(1, len(page_splits), 2):
            pno = int(page_splits[i])
            content = page_splits[i + 1]
            line_boxes = {}
            for rm in rec_re.finditer(content):
                rtype = rm.group(1)
                tag = int(rm.group(2))
                line = int(rm.group(3))
                rel = inputs.get(tag)
                if not rel or line <= 0 or rtype not in ("(", "h", "g", "x"):
                    continue
                x = int(rm.group(4)) / 65536.0
                y = int(rm.group(5)) / 65536.0
                w = int(rm.group(6)) / 65536.0 if rm.group(6) else 0.0
                h = int(rm.group(7)) / 65536.0 if rm.group(7) else 0.0
                if y < 45 or y > 805 or x < 30 or x > 565 or h > 200:
                    continue
                key = (rel, line)
                if key not in line_boxes:
                    line_boxes[key] = [x, x + max(0.0, w), y, y, max(h, 10.0)]
                else:
                    b = line_boxes[key]
                    b[0] = min(b[0], x)
                    b[1] = max(b[1], x + max(0.0, w))
                    b[2] = min(b[2], y)
                    b[3] = max(b[3], y)
                    b[4] = max(b[4], h)

            p_arr = []
            for (rel, line), b in line_boxes.items():
                entry = {
                    "path": rel,
                    "line": line,
                    "page": pno,
                    "x": round(b[0], 1),
                    "yMin": round(b[2], 1),
                    "yMax": round(b[3], 1),
                    "w": round(max(24.0, b[1] - b[0]), 1),
                    "h": round(b[4], 1)
                }
                p_arr.append(entry)
                forward.setdefault(rel, {})
                if str(line) not in forward[rel]:
                    forward[rel][str(line)] = entry
            p_arr.sort(key=lambda item: item["yMin"])
            pages[str(pno)] = p_arr

        out_path = os.path.join(STUDIO_DIR, "synctex_map.json")
        with open(out_path, "w", encoding="utf-8") as out_f:
            json.dump({"forward": forward, "pages": pages}, out_f, separators=(",", ":"))



def run_server(port=DEFAULT_PORT):
    server = ThreadedHTTPServer(("0.0.0.0", port), StudioHandler)
    print("=" * 65)
    print(f" BLACK BOOK WEB STUDIO ACTIVE")
    print(f" Workspace Root : {BLACK_BOOK_DIR}")
    print(f" Studio URL     : http://localhost:{port}")
    print(f" Direct Storage : 100% Persistent on Local Hard Drive")
    print("=" * 65)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Black Book Web Studio...")
        server.server_close()


if __name__ == "__main__":
    port = DEFAULT_PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port)
