# LaTeX Bible — Engineering Capstone Dissertation Specification

> **Purpose:** This file is the single source of truth for the final-year engineering capstone dissertation ("Black Book") in `black_book/`. It documents the structure, mathematical formulations, figures, tables, code listings, academic standards, and team metadata across all `.tex` files, ensuring complete continuity.
> **Rule:** This file MUST be updated whenever any `.tex` file in `black_book/` is modified.
> **Last Synchronized:** 2026-10-09 (Session 25 — Layout Alignment, Density Balancing & Capstone Completion Audit)

---

## 1. Document Standards & Compilation Environment

- **Target Institution:** MIT World Peace University (MIT-WPU), Pune
- **Department:** Department of Electrical & Electronics Engineering (EEE), School of Engineering and Technology
- **Degree:** Bachelor of Technology (B.Tech) in Electrical & Electronics Engineering
- **Course Code:** `ECE4PR01A`
- **Group Number:** `2627S7-121`
- **Internal Project Guide:** Prof. Aarti Vagga (Assistant Professor, Department of EEE)
- **Project Co-Guide:** Dr. Vaidehi Deshmukh (Associate Professor, Department of EEE)
- **Student Authors:**
  - Soham Bhavsar (PRN: `1032232422`)
  - Toshal Kumbhar (PRN: `1032232541`)
  - Divyansh Dewangan (PRN: `1032233211`)
- **Formatting Guidelines:**
  - **Paper Size:** ISO A4 (`210mm \times 297mm`)
  - **Margins:** Balanced, symmetric horizontal and vertical margins:
    - `left = 25mm`, `right = 25mm` (`\textwidth = 160mm`)
    - `top = 25mm`, `bottom = 25mm`, `footskip = 12mm` (`\textheight = 247mm`)
    - Ensures perfectly centered text blocks on every page with equal white margins on both sides.
  - **Float Placement Optimization:**
    - `\renewcommand{\topfraction}{0.85}`
    - `\renewcommand{\bottomfraction}{0.85}`
    - `\renewcommand{\textfraction}{0.15}`
    - `\renewcommand{\floatpagefraction}{0.8}`
    - Eliminates arbitrary top and bottom blank spots, preventing premature section breaks.
  - **Line Spacing:** 1.5 line pitch (`\onehalfspacing` via `setspace`)
  - **Typography:** Times New Roman (`mathptmx` package)
  - **Page Numbering:** Two-tier schema:
    - Lowercase Roman (`i, ii, iii...`) for Front Matter (Title through Abbreviations)
    - Arabic numerals (`1, 2, 3...`) starting from Chapter 1 through Appendices
  - **Running Headers:** `fancyhdr` with chapter titles and horizontal rule ($159.2\text{ mm}$ width).
- **Compilation Engine:** **Tectonic** (`/opt/homebrew/bin/tectonic main.tex`)
- **Git Repository:** `https://github.com/SohamBhavsar24/black-book.git` (tracked on branch `main`)
- **Total Page Count:** **63 Pages** (publication-grade, zero abrupt endings, dense layouts).

---

## 2. Verified Physical Ground Truth Hardware & Rig Geometry

Based on complete project audits of `firmware/robot_driver/robot_driver.ino`, `architecture.md`, and `poster/index.html`:

| Subsystem | Ground Truth Specification | Description / Role |
|---|---|---|
| **Mounting Baseboard** | $50\text{ cm} \times 50\text{ cm}$ Wooden Plank | Rigid baseplate absorbing dynamic reaction torques during multi-axis manipulator motions |
| **Arm Placement** | Mounted on one side of plank | Anchored at the edge/pedestal to maximize reach into the forward manipulation field |
| **Active Workspace** | $25\text{ cm} \times 30\text{ cm}$ White Workspace | Calibrated tabletop manipulation area in front of the arm ($X \in [0, 30]\text{ cm}$, $Y \in [0, 25]\text{ cm}$) |
| **World Origin Fiducial** | ArUco Marker ID 2 on corner | Mounted at the corner of the workspace sheet, establishing the metric origin $(0, 0)\text{ cm}$ |
| **Manipulation Targets** | $4\text{ cm} \times 4\text{ cm} \times 4\text{ cm}$ Sponge Cubes | Lightweight blocks with ArUco markers on top (Tag 0: Block 1, Tag 1: Block 2) |
| **Vision System** | Logitech C270 HD USB Camera | Mounted on a rigid vertical pole/mast past the white workspace looking straight down (orthogonal top-down perspective, 30 FPS MJPEG) |
| **Base Actuator** | MG996R Servo (Channel 0) | Turntable azimuthal pivot ($\theta_1$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Shoulder Actuator** | MG996R Servo (Channel 2) | Upper arm elevation pitch ($\theta_2$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Elbow Actuator** | MG996R Servo (Channel 4) | Forearm articulation pitch ($\theta_3$, $11.0\text{ kg}\cdot\text{cm}$ torque) |
| **Wrist Pitch Actuator** | MG90S Micro Servo (Channel 6) | End-effector pitch orientation ($\theta_4$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Wrist Roll Actuator** | MG90S Micro Servo (Channel 8) | End-effector axial rotation ($\theta_5$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Gripper Jaw Actuator**| MG90S Micro Servo (Channel 10)| Parallel claw rack-and-pinion ($\theta_6$, $2.2\text{ kg}\cdot\text{cm}$ metal gear) |
| **Servo Driver** | NXP PCA9685 16-Channel 12-Bit | I2C PWM controller ($50\text{ Hz}$ update, 4096-step resolution, $400\text{ kHz}$ Fast I2C) |
| **Microcontroller** | Original Arduino Uno Rev3 | ATmega328P executing 115200 baud binary serial framing with 500ms safety watchdog |
| **Servo Power Supply** | 6V 5A External DC Power Supply | Dedicated high-current rail powering PCA9685 $V+$ and servos; common ground with Uno |
| **Power Decoupling** | $1000\,\mu\text{F}$ 16V Electrolytic Cap | Absorbs transient current spikes up to $4.2\text{A}$ without voltage drop |
| **Logic Power Supply** | 5V USB / Regulated Rail | Powers Arduino Uno logic circuits and PCA9685 VCC independently |
| **Safety E-Stop** | Physical Cutoff Toggle Switch | Hardware switch instantly breaking the 6V servo power supply line |

---

## 3. Directory Structure & Master File Mapping

```
black_book/
├── main.tex                               # Master root LaTeX document & preambles
├── latex_bible.md                         # This file: single source of truth for LaTeX project
├── frontmatter/
│   └── frontmatter.tex                    # Title (top logo), Certificate, Declaration, Acknowledgement, Abstract
├── chapters/
│   ├── ch1_introduction.tex               # Background, Problem Formulation (MDP), Constraints Table, Objectives, Scope
│   ├── ch2_literature_survey.tex          # Classical DLS IK, Imitation Learning, ACT, VLA & Diffusion Policies, Taxonomy Matrix
│   ├── ch3_hardware_and_kinematics.tex    # Mechanical CAD, 3D FK/IK, Actuation, ROS 2 URDF, Uno Firmware Protocol
│   ├── ch4_perception_pipeline.tex        # 50x50 Rig, 25x30 Workspace, Camera Matrix, Distortion, Homography, Radar
│   ├── ch5_imitation_learning_and_act.tex # Teleop Data, 750-Episode Corpus, Pure-NumPy ACT Math, Hyperparameter Table, BLAS
│   ├── ch6_challenges_and_problem_solving.tex # 8 Major Engineering Hurdles Solved + Comprehensive Challenge Matrix
│   ├── ch7_experimental_results.tex       # Ablation Benchmarks, Loss Curves, Failure Mode Taxonomy, Thermal Profile
│   └── ch8_conclusion_and_future_work.tex # Full Capstone Synthesis, Reflections, Societal Impact, Roadmap Table, Epilogue
├── appendices.tex                         # Appendix A (BOM), B (Uno Pinout), C (ACT Code), D (Journal + Narrative), E (QA & Sign-off)
├── references.bib                         # 22 IEEE-formatted academic citations
└── figures/                               # Vector and schematic diagram resources (college_logo.png)
```

---

## 4. Comprehensive Chapter & File Breakdown

### 4.1 `main.tex`
- **Preamble:**
  - Geometry: `a4paper, left=25mm, right=25mm, top=25mm, bottom=25mm, footskip=12mm`.
  - Float optimization parameters to guarantee dense page packing.
  - Times New Roman typography via `mathptmx`.
  - Tight enumitem spacing (`nosep`).
- **Abbreviations Environment:**
  - Standardized `tabular*` spanning `\textwidth` ($160\text{ mm}$) with `lp{125mm}`.

### 4.2 `frontmatter/frontmatter.tex`
- **Title Page:** College logo positioned prominently at the top (`\includegraphics[width=32mm]{figures/college_logo.png}`), followed by Department of EEE, School of Engineering & Technology, MIT-WPU, Course Code (`ECE4PR01A`), Group No (`2627S7-121`), Candidates with PRNs, Guide (`Prof. Aarti Vagga`), Co-Guide (`Dr. Vaidehi Deshmukh`), and Academic Year 2026--2027.
- **Certificate of Approval:** Official bonafide record citing candidates, PRNs, guide, co-guide, and signature rules for Guide, Co-Guide, Head of Department, Dean, and External Examiner.
- **Candidates' Declaration:** Formal candidate declaration under Prof. Aarti Vagga and Dr. Vaidehi Deshmukh.
- **Acknowledgement:** Technical gratitude to guide, co-guide, HOD, Dean, and lab staff.
- **Abstract:** Concise 4-paragraph technical summary citing Course Code and Group No.

### 4.3 `chapters/ch1_introduction.tex`
- **Section 1.1:** Background and industrial manipulation economics.
- **Section 1.2:** Formal mathematical problem formulation framing pick-and-place as an MDP with state $\mathbf{s}_t \in \mathbb{R}^8$, action $\mathbf{a}_t \in \mathbb{R}^6$, and imitation objective $\min_\theta \mathbb{E}_{\tau \sim \mathcal{D}} [\sum \mathcal{L}(\mathbf{a}_t, \pi_\theta(\mathbf{s}_t))]$.
- **Section 1.3:** Engineering Specifications and Design Constraints Table (Table 1.1) detailing workspace, payload, accuracy, cycle time, compute budget, BOM cost, firmware latency, and watchdog response.
- **Section 1.4:** Eight specific measurable technical objectives.
- **Section 1.5:** Scope and boundary limitations.
- **Section 1.6:** Organization of the dissertation.

### 4.4 `chapters/ch2_literature_survey.tex`
- **Section 2.1:** Evolution across Classical Kinematics, DRL, and Visuomotor Imitation Learning.
- **Section 2.2:** Classical Control, Damped Least-Squares (DLS) Jacobian formulation ($\mathbf{J}^* = \mathbf{J}^\top(\mathbf{J}\mathbf{J}^\top + \lambda^2\mathbf{I})^{-1}$), potential fields, and S-curve acceleration.
- **Section 2.3:** Imitation Learning, Behavioral Cloning, and covariate shift analysis.
- **Section 2.4:** Action Chunking with Transformers (ACT) and attention mathematics ($\text{softmax}(\mathbf{Q}\mathbf{K}^\top/\sqrt{d_k})\mathbf{V}$).
- **Section 2.5:** Modern Diffusion Policies and Vision-Language-Action (VLA) foundation models (RT-1, RT-2, OpenVLA), establishing why edge-optimized ACT is ideal for low-cost embedded hardware.
- **Section 2.6:** Optical fiducial tracking and sub-pixel Harris corner refinement.
- **Section 2.7:** Trajectory interpolation and Inverse Distance Weighting (IDW).
- **Section 2.8:** Robotics middleware (ROS 2 Humble, DDS, Gazebo, MoveIt 2).
- **Section 2.9:** Comparative Literature Matrix (Table 2.1) contrasting Industrial Cobots, GPU-based SOTA (ALOHA), and the proposed edge architecture.

### 4.5 `chapters/ch3_hardware_and_kinematics.tex`
- **Section 3.1:** 6-DOF mechanical serial chain modeling in Fusion 360, PLA structural specifications.
- **Figure 3.1:** Kinematic Link Blueprint TikZ vector diagram.
- **Section 3.2:** Analytical Forward Kinematics (FK) and closed-form planar 2-link trigonometric Inverse Kinematics (IK) with algebraic branch selection.
- **Section 3.3:** Actuator selection (3× MG996R + 3× MG90S), PCA9685 12-bit PWM driver, and external 6V 5A power rail.
- **Figure 3.2:** Complete electrical interconnect schematic TikZ diagram (Arduino Uno Rev3, PCA9685, 6V 5A DC supply, 1000uF cap).
- **Section 3.4:** ROS 2 URDF description, MoveIt 2 planning, and Jacobian singularity condition analysis ($\kappa = 2.88$).
- **Section 3.5:** Arduino Uno firmware protocol, binary serial framing (`0xFF` SOF, 6 joint bytes, `0xFE` EOF), and 500ms safety watchdog auto-homing.

### 4.6 `chapters/ch4_perception_pipeline.tex`
- **Section 4.1:** Physical testbed rig geometry ($50\times 50\text{ cm}$ wooden plank, one-side arm mount, $25\times 30\text{ cm}$ white workspace, corner Tag 2 origin, overhead pole-mounted Logitech C270).
- **Section 4.2:** Camera intrinsic calibration matrix ($\mathbf{K}_{3\times 3}$) and Brown-Conrady 5-parameter lens distortion modeling ($k_1, k_2, p_1, p_2$).
- **Section 4.3:** ArUco fiducial marker tracking and sub-pixel Harris corner refinement math.
- **Figure 4.1:** Complete Testbed Geometry Blueprint TikZ vector drawing.
- **Section 4.4:** World coordinate transformation and planar homography matrix ($\mathbf{H}_{3\times 3}$).
- **Section 4.5:** Real-time 2D SVG Workspace Radar.
- **Section 4.6:** Dual-block sequential sorting and downstream sweep priority.

### 4.7 `chapters/ch5_imitation_learning_and_act.tex`
- **Section 5.1:** Teleoperation demonstration collection with PS5 DualSense controller and EMA low-pass filtering.
- **Section 5.2:** Decoupled task decomposition (neural visual pick + deterministic Cosine S-Curve drop transfer).
- **Section 5.3:** Behavioral Cloning MLP baseline formulation and dual-head loss.
- **Section 5.4:** Action Chunking with Transformers (ACT) architecture, learned temporal query tokens ($H=24$), and attention mathematics.
- **Figure 5.1:** Complete ACT Architecture TikZ block diagram.
- **Section 5.5:** Synthetic dataset expansion (750 total episodes) and closed-form joint mapping equations.
- **Section 5.6:** Pure-NumPy BLAS acceleration engine via contiguous 2D matrix flattening ($32.6\times$ speedup, $4.9\text{s/epoch}$).
- **Table 5.1:** Complete Structural and Training Hyperparameter Table.
- **Section 5.7:** Receding horizon temporal ensembling with exponential decay weighting ($w_k = \exp(-0.05k)$).
- **Section 5.8:** Two-stage phase-aligned IDW demonstration blending.

### 4.8 `chapters/ch6_challenges_and_problem_solving.tex`
- Dedicated, exhaustive analysis of the 8 major engineering challenges solved across the project lifecycle:
  1. Microcontroller brownouts and PCA9685 crosstalk ($1000\,\mu\text{F}$ cap + spaced channels).
  2. Serial telemetry packet corruption (binary framing + 500ms watchdog).
  3. Tabletop penetration and physical collisions (3D WebGL mesh forward geofencing).
  4. Kinematic singularities in teleoperation (rate velocity control + condition monitoring).
  5. Optical ArUco yaw jitter (feature dimensionality ablation).
  6. Demonstration class imbalance (kinematic Descent-Apex Grasp Detector $\theta_3 \ge 154^\circ$).
  7. Multi-modal drop trajectory smearing (decoupled pick/place architecture).
  8. Edge CPU inference bottlenecks (pure-NumPy 2D matrix flattening to BLAS).
- **Table 6.1:** Impact of Feature Dimensionality Ablation.
- **Table 6.2:** Comprehensive Summary Matrix of All Challenges and Mitigations.

### 4.9 `chapters/ch7_experimental_results.tex`
- **Section 7.1:** Experimental setup and 30-cell grid test protocol across 4 registered policies (`v1`, `excluding_block_theta`, `act_with_theta`, `act_no_theta`).
- **Section 7.2:** Training loss convergence profiles across 30, 60, and 90 human teleoperation demonstration tiers (Figure 7.1 and Table 7.1).
- **Section 7.3:** Multi-tier physical pick-and-place empirical matrices across 30, 60, and 90 demonstrations (30 physical trials per model per tier, 360 total physical trials):
  - **Table 7.2 (30 Demos -- Low-Data Regime):** MLP outperforms ACT due to lower parameter capacity and stronger low-data inductive bias (`v1` MLP Baseline: $13/30 = 43.3\%$, `excluding_block_theta` MLP No Theta: $14/30 = 46.7\%$, `act_with_theta`: $10/30 = 33.3\%$, `act_no_theta`: $11/30 = 36.7\%$).
  - **Table 7.3 (60 Demos -- Intermediate Crossover Regime):** ACT overcomes low-sample overfitting and overpowers MLP (`v1`: $15/30 = 50.0\%$, `excluding_block_theta`: $17/30 = 56.7\%$, `act_with_theta`: $19/30 = 63.3\%$, `act_no_theta`: $21/30 = 70.0\%$).
  - **Table 7.4 (90 Demos -- High-Data Scaling & MLP Saturation Regime):** MLP hits an asymptotic accuracy saturation ceiling due to single-step Markovian drift (`v1`: $16/30 = 53.3\%$, `excluding_block_theta`: $18/30 = 60.0\%$, only $+3.3\%$ gain over 60 demos), whereas ACT scales steeply to dominate physical manipulation (`act_with_theta`: $24/30 = 80.0\%$, `act_no_theta`: $26/30 = 86.7\%$).
  - **Table 7.5 & Figure 7.2:** Cross-tier dataset scaling synthesis table and TikZ scaling/saturation curve plot showing capacity crossover ($N \approx 42$) and MLP plateau vs ACT scaling.
- **Section 7.4:** Failure mode taxonomy and distribution breakdown across the 90-demo evaluation benchmark (Table 7.6).
- **Section 7.5:** Thermal profile and current draw benchmarks during continuous 1-hour operation.
- **Section 7.6:** Analytical discussion of low-data inductive bias, 60-demo crossover, 90-demo MLP saturation, receding horizon ensembling, and $\theta$ feature ablation.

### 4.10 `chapters/ch8_conclusion_and_future_work.tex`
- **Section 8.1:** Comprehensive research synthesis auditing all 8 project objectives against delivered metrics (including the 30/60/90 demonstration scaling progression).
- **Section 8.2:** Pedagogical reflections and core engineering competencies developed.
- **Section 8.3:** Societal, economic, and environmental impact (techno-economic comparison against $\$15,000$ cobots, $98\%$ carbon reduction via edge compute).
- **Section 8.4:** Phased Future Research Roadmap (Table 8.1: Phase I to Phase IV spanning 2027).
- **Section 8.5:** Formal concluding remarks, epilogue, and official open-source repository link (`https://github.com/SohamBhavsar24/vision-autonomous-robotic-arm.git`).

### 4.11 `appendices.tex`
- **Appendix A:** System Bill of Materials (Table A.1: total cost $\text{INR }12,440 \approx \$149.00$).
- **Appendix B:** Microcontroller Pinout and Interconnect Wiring (Table B.1: Arduino Uno Rev3 to PCA9685 and servos).
- **Appendix C:** Core Pure-NumPy ACT Attention Engine (Listing C.1: 2D matrix flattening dispatch to BLAS).
- **Appendix D:** Project Engineering Journal (Table D.1: complete 29-session Supabase logbook + analytical narrative).
- **Appendix E:** Quality Assurance Checklist (Table E.1), Formal Academic Sign-Off Signature Block (Candidates, Guide, Co-Guide, HOD, Dean, Examiner), and Repository Archival Metadata (`https://github.com/SohamBhavsar24/vision-autonomous-robotic-arm.git`).

### 4.12 `references.bib`
- 22 seminal, peer-reviewed citations in IEEE format covering robotics, computer vision, transformers, imitation learning, and foundation models, spanning exactly two dense, balanced pages.

---

## 5. Black Book Web Studio (Overleaf-Style Local Web Editor)

To facilitate direct interactive editing, image uploads, live Tectonic recompilation, and continuous PDF preview without relying on cloud subscriptions (e.g. Overleaf), an independent, self-hosted web studio application is deployed directly inside `black_book/studio/`.

- **Backup Safety Mirror:** A full physical backup preserving the original pristine 63-page state is archived at `/Users/sohambhavsar/Desktop/Autonomoous arm/black_book_backup/`.
- **Operating Target:** All web edits, saves, and compilations execute directly on `/Users/sohambhavsar/Desktop/Autonomoous arm/black_book/`.
- **Launcher Script:** `./start_black_book_studio.sh` (workspace root).
- **Default Port:** `http://localhost:8060`.
- **Architecture & Persistence:**
  - Zero external package dependencies: Python multithreaded backend (`black_book/studio/server.py`).
  - Direct Disk Persistence: Saves write immediately to `.tex` files on disk; uploaded images are saved to `black_book/figures/`.
  - Survives server stops, restarts, and system reboots with 100% data retention.
- **REST Endpoints:**
  - `GET /api/tree`: Hierarchical file tree of Core, Front Matter, Chapters, Back Matter, Figures, and Docs.
  - `GET /api/file?path=<rel_path>`: Reads raw file text with UTF-8 decoding.
  - `POST /api/save`: Persists edited content directly to disk.
  - `POST /api/upload_image`: Saves base64/binary image to `figures/` and returns formatted `\begin{figure}` LaTeX snippet.
  - `POST /api/compile`: Spawns Tectonic subprocess (`--synctex`), rebuilds `studio/synctex_map.json`, and returns execution time, exit code, and live compiler logs.
  - `GET /api/pdf`: Direct stream of `main.pdf` with cache-busting timestamping.
  - `GET /api/synctex_map`: Serves pre-parsed SyncTeX coordinate index (`synctex_map.json`) mapping `(file, line) <-> (page, x, yMin, yMax)` in PDF points.
  - `GET /api/figures`: Gallery listing of all image assets in `figures/`.
  - `GET /api/status`: Returns PDF file existence, last modified timestamp (mtime), and file size for silent 10s polling.
  - `POST /api/search_code`: Combines compiler SyncTeX `(page, x, y)` positional lookup with local line/word offset disambiguation so repeated words on different pages jump to the exact occurrence.
  - `POST /api/repack_zip`: Packages `Black_Book_LaTeX_Project.zip`.
  - `POST /api/git_sync`: Automates git staging, commit, and push to GitHub remote.

### 5.1 Advanced Studio Capabilities (Sessions 26--28 Implementation)
- **Continuous Multi-Page PDF.js Rendering Engine:**
  - Migrated from browser native iframe embedding to Mozilla PDF.js v3.11 with dedicated worker.
  - Renders all 65 pages continuously in vertical order with IntersectionObserver viewport lazy loading.
  - Zoom range from 50% to 400% (beyond 100%), with presets, Fit Width mode, Fit Page mode, and Cmd/Ctrl + Trackpad/Wheel smooth zooming.
- **Interactive Resizable Panel Splitter:**
  - Full draggable splitter gutter between Editor and PDF Preview panes.
  - Real-time dragging with bounds protection (min 280px editor, min 320px preview).
  - Split position persisted in browser `localStorage.getItem('blackbook_editor_width')`.
  - Double-click resets layout to 50/50 balance.
- **Compiler-Grade SyncTeX Bidirectional Code <-> PDF Synchronization:**
  - **Code to PDF:** Uses `synctex_map.json` generated directly from `main.synctex.gz` to resolve the exact PDF page and vertical bounding band `(yMin, yMax)` for any `(file, line)` in the editor, combined with cursor word disambiguation so repeated words (e.g., candidate names or common terms) highlight the exact occurrence on the exact page.
  - **PDF to Code:** Computes the exact PDF point coordinates `(page, xPt, yPt)` of the selected text span in the PDF preview and queries `/api/search_code` with SyncTeX coordinate filtering (`±6 lines` around the compiler's SyncTeX line record), jumping directly to the exact file, line, and character range.
- **Non-Disruptive 10-Second Auto-Refresh:**
  - Background polling interval checks `/api/status` every 10 seconds.
  - Detects PDF updates without disrupting the user: records scroll ratios and reloads PDF quietly in the background without resetting scroll position or jumping the screen.
